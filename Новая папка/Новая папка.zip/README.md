# Dots animation example with Three.js
```
npm i
npm start
```
Will run server on :3000, where you can see example of animation.
Details in this [video stream](https://www.youtube.com/watch?v=Q9BXGh9sdZw) (russian language)

# Inspired by
* By animations on this website [Noni](https://noni.cmiscm.com/)
